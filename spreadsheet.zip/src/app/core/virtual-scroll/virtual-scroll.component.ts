import { AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, ContentChild, ElementRef, Input, OnChanges, SimpleChanges, TemplateRef, ViewChild } from '@angular/core';
import { CellComponent } from '../cell/cell.component';
import { HeaderCellComponent } from '../header-cell/header-cell.component';
import { Cell } from './../cell';
import { Row } from './../row';

const VIRTUAL_SCROLL_OFFSET = 200; // offset at which virtual scroll hooks in
@Component({
  selector: 'app-virtual-scroll',
  templateUrl: './virtual-scroll.component.html',
  styleUrls: ['./virtual-scroll.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class VirtualScrollComponent implements AfterViewInit, OnChanges {
  rows: Row[];
  @Input('rows') set _rows(rows: Row[]) {
    this.rows = rows;
    this.startRowIndex = 0;
    this.endRowIndex = this.rows.length - 1;
    this.scroll(null);
  }
  @Input() columns: Row;
  @ContentChild('cellTemplate', { static: true }) cellTemplate: TemplateRef<CellComponent>;
  @ContentChild('headerCellTemplate', { static: true }) headerCellTemplate: TemplateRef<HeaderCellComponent>;
  @ViewChild('content', { static: false }) content: ElementRef;
  @ViewChild('headerHorizontal', { static: true }) headerHorizontal: ElementRef;
  @ViewChild('headerVertical', { static: true }) headerVertical: ElementRef;
  @ViewChild('scrollContainer', { static: true }) set scrollContainer(container: ElementRef) {
    this.container = container;
    this.scroll(null);
  }

  rowIndices: number[];
  columnIndices: number[];
  startRowIndex: number;
  endRowIndex: number;
  offsetTop: number;
  startColIndex: number;
  endColIndex: number;
  offsetLeft: number;

  private _lastScrollPositionTop: number;
  private _lastScrollPositionLeft: number;
  private container: ElementRef;
  constructor(private cd: ChangeDetectorRef) { }

  private getOffsetIndex(offset: number, list: any[], attr: 'width' | 'height'): any {
    let sum = 0;
    let index = 0;
    for (const item of list) {
      if (sum + item[attr] > offset) {
        return { index, sum };
      }
      sum += item[attr];
      index++;
    }
    return { index, sum };
  }

  ngAfterViewInit(): void {
    this.cd.detectChanges();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.rows || changes.columns) {
      this.scroll(null);
    }
  }

  public scroll(event: Event): void {

    if (!this.container) { return; }
    const top: number = event ? (event.target as any).scrollTop : 0;
    const left: number = event ? (event.target as any).scrollLeft : 0;

    if (this._lastScrollPositionTop !== top && this.rows) {
      this._lastScrollPositionTop = top;
      const start = this.getOffsetIndex(top - VIRTUAL_SCROLL_OFFSET, this.rows, 'height');
      const end = this.getOffsetIndex(top + this.container.nativeElement.clientHeight + VIRTUAL_SCROLL_OFFSET, this.rows, 'height');
      this.startRowIndex = start.index;
      this.endRowIndex = end.index;
      this.offsetTop = start.sum;
    }

    if (this._lastScrollPositionLeft !== left && this.columns) {
      this._lastScrollPositionLeft = left;
      const start = this.getOffsetIndex(left - VIRTUAL_SCROLL_OFFSET, this.columns.cells, 'width');
      const end = this.getOffsetIndex(left + this.container.nativeElement.clientWidth + VIRTUAL_SCROLL_OFFSET, this.columns.cells, 'width');
      this.startColIndex = start.index;
      this.endColIndex = end.index;
      this.offsetLeft = start.sum;
    }

    if (this.headerHorizontal) {
      this.headerHorizontal.nativeElement.scrollLeft = left;
    }

    if (this.headerVertical && this.content) {
      setTimeout(() => {
        this.headerVertical.nativeElement.scrollTop = this.content.nativeElement.scrollTop;
      }, 0);
    }

    if (this.rows) {
      this.rowIndices = [];
      for (let i = this.startRowIndex; i < this.endRowIndex; i++) {
        this.rowIndices.push(i);
      }
    }

    if (this.columns) {
      this.columnIndices = [];
      for (let i = this.startColIndex; i < this.endColIndex; i++) {
        this.columnIndices.push(i);
      }
    }

    if (this.headerHorizontal && this.content) {
      setTimeout(() => {
        this.headerHorizontal.nativeElement.scrollLeft = this.content.nativeElement.scrollLeft;
      }, 0);
    }
  }

  trackByFn(index: number) { return index; }

  get combinedRowHeight(): number {
    return this.rows ? this.rows.map((row: Row) => row.height).reduce((accu: number, cur: number) => accu + cur) : 0;
  }

  get scrollbarWidth(): number {
    if (!this.content) { return 0; }
    return this.content.nativeElement.offsetWidth - this.content.nativeElement.clientWidth;
  }

  get combinedColWidth(): number {
    return this.columns ? this.columns.cells.map((col: Cell) => col.width).reduce((accu: number, cur: number) => accu + cur) : 0;
  }
}
