import { Injectable } from '@angular/core';
import { Row } from '../row';
import { SelectionArea, SelectionBorders } from './selection';
import { Cell } from './../cell';
import { Subject } from 'rxjs';

@Injectable()
export class SelectionModelService {
  private _selections: SelectionArea[];
  private _currentSelection: SelectionArea;
  private _currentSelectedCell: Cell;
  public currentSelectedCellChange: Subject<Cell> = new Subject<Cell>();

  public get currentSelectedCell(): Cell {
    return this._currentSelectedCell;
  }

  public setCurrentSelectedCell(currentSelectedCell: Cell) {
    this._currentSelectedCell = currentSelectedCell;
    this.currentSelectedCellChange.next(this._currentSelectedCell);
  }

  public get selections(): SelectionArea[] {
    return this._selections;
  }

  public set selections(selections: SelectionArea[]) {
    this._selections = selections;
  }

  public isCurrentSelected(cell: Cell): boolean {
    if (!this.currentSelectedCell) { return false; }
    return cell.row === this.currentSelectedCell.row && cell.col === this.currentSelectedCell.col;
  }

  public clearSelection(): void {
    this._selections = [];
    this.setCurrentSelectedCell(null);
    this._currentSelection = null;
  }

  public click(cell: Cell): void {
    this._selections = [];
    this._selections.push(new SelectionArea(cell.row, cell.col, cell.row, cell.col));
  }

  public up(event: MouseEvent, cell: Cell, row?: Row) {
    if (!this._currentSelection) { return; }

    const col = row ? Math.max(...row.cells.map((innerCell: Cell) => innerCell.col)) : cell.col;
    const area = new SelectionArea(this._currentSelection.startRow, this._currentSelection.startCol, cell.row, col);
    area.id = this._currentSelection.id;

    this._selections = this._selections.filter((sArea: SelectionArea) => sArea.id !== area.id);

    this._selections.push(area);
    this._currentSelection = null;
  }

  public moveCurrent(pos: 'up' | 'down' | 'left' | 'right') {
    if (!this.currentSelectedCell) { return; }
    const cell: Cell = this.currentSelectedCell;
    switch (pos) {
      case 'up':
        console.log('YEAH')
        cell.row = cell.row === 0 ? 0 : cell.row - 1;
        break;
      case 'left':
        cell.col = cell.col === 0 ? 0 : cell.col - 1;
        break;
      case 'down':
        cell.row = cell.row + 1;
        break;
      case 'right':
        cell.col = cell.col + 1;
        break;
    }
    this.setCurrentSelectedCell(cell);
    console.log(this.currentSelectedCell)
  }

  public over(event: MouseEvent, cell: Cell, row?: Row) {
    if (!this._currentSelection) { return; }
    const col = row ? Math.max(...row.cells.map((innerCell: Cell) => innerCell.col)) : cell.col;

    this._currentSelection.endCol = col;
    this._currentSelection.endRow = cell.row;
  }

  public extendSelection(selection: SelectionArea) {

  }

  public down(event: MouseEvent, cell: Cell, row?: Row) {

    let endCol = cell.col;
    if (row) {
      console.log(event, cell, row)
      endCol = Math.max(...row.cells.map((rowCell: Cell) => rowCell.col));
    }
    this._currentSelection = new SelectionArea(cell.row, cell.col, cell.row, endCol);


    if (event.shiftKey && this._selections) {
      const select: SelectionArea = this._selections.pop();
      console.log('SELCT', this._selections, select)
      if (select) {
        this._currentSelection.startRow = select.startRow;
        this._currentSelection.startCol = select.startCol;
      }
    } else {
      this.setCurrentSelectedCell(cell);
    }

    if (!this._selections || !event.ctrlKey) {
      this._selections = [];
    }

    this._selections.push(this._currentSelection);
  }

  public isEndOfSelection(cell: Cell): boolean {
    if (!this._selections) { return false; }
    const area: SelectionArea = this._selections[this._selections.length - 1];


    return Math.max(area.endRow, area.startRow) === cell.row && Math.max(area.endCol, area.startCol) === cell.col;
  }

  public getBorders(cell: Cell): string {
    if (!this.selections) {
      return '';
    }

    const borders: SelectionBorders = {
      top: this.selections.map((area: SelectionArea) => area.getBorder(cell).top).find((border: boolean) => border === true),
      bottom: this.selections.map((area: SelectionArea) => area.getBorder(cell).bottom).find((border: boolean) => border === true),
      left: this.selections.map((area: SelectionArea) => area.getBorder(cell).left).find((border: boolean) => border === true),
      right: this.selections.map((area: SelectionArea) => area.getBorder(cell).right).find((border: boolean) => border === true),
    };

    let result = '';
    for (const key of Object.keys(borders)) {
      if (borders[key]) {
        result += ` ${key}`;
      }
    }
    return result;
  }

  public getSelectionCount(cell: Cell): number {
    let count = 0;
    if (!this._selections) { return 0; }
    this._selections.forEach((area: SelectionArea) => {
      if (area.isInside(cell)) {
        count++;
      }
    });

    return count / (12 + count);
  }

}
