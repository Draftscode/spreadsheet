import { Component, Input, OnDestroy, HostListener } from '@angular/core';
import { takeWhile } from 'rxjs/operators';
import { Cell } from '../cell';
import { SelectionModelService } from '../provider/selection-model.service';
import { Row } from '../row';

@Component({
  selector: 'app-spreadsheet-cell',
  templateUrl: './cell.component.html',
  styleUrls: ['./cell.component.scss'],
})
export class CellComponent implements OnDestroy {
  @Input() width: number;
  @Input() height: number;
  @Input() cell: Cell;
  @Input() row: Row;
  mode: ECellMode = ECellMode.DEFAULT;
  private alive = true;
  private clickCount = 0;

  constructor(
    public selectionModel: SelectionModelService,
  ) {}



  @HostListener('document:keydown', ['$event']) onKey(event: KeyboardEvent) {
    console.log(event.key)
    if (this.selectionModel.isCurrentSelected(this.cell)) {

    } else {
    }
  }

  handleClick(event: MouseEvent) {
    if (this.clickCount === 1) {
      this.mode = ECellMode.EDITOR;
    } else {
      this.clickCount++;
    }

    setTimeout(() => {
      this.clickCount = 0;
    }, 400);
  }


  ngOnDestroy(): void {
    this.alive = false;
  }

  onDragEnd(event) {
    console.log(event);
  }

}

export enum ECellMode {
  DEFAULT = 'default', EDITOR = 'editor',
}
