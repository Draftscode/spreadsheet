import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CellComponent } from './cell.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { EditorModule } from '../editor/editor.module';

@NgModule({
  imports: [
    CommonModule,
    DragDropModule,
    DragDropModule,
    EditorModule,
  ],
  declarations: [CellComponent],
  exports: [CellComponent]
})
export class CellModule { }
