export class Cell {
  label: string;
  row: number;
  col: number;
  width: number;
  type: any;
  value: any;



  constructor(col?: number, row?: number, label?: string) {
    this.col = col; this.row = row; this.label = label;
  }

}
