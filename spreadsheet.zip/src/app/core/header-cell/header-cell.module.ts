import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { HeaderCellComponent } from './header-cell.component';

@NgModule({
  imports: [
    CommonModule,
    DragDropModule,
  ],
  declarations: [HeaderCellComponent],
  exports: [HeaderCellComponent]
})
export class HeaderCellModule { }
