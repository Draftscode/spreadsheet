import { CdkDragEnd } from '@angular/cdk/drag-drop';
import { Component, Input } from '@angular/core';
import { Cell } from '../cell';
import { SelectionModelService } from '../provider/selection-model.service';
import { Row } from '../row';

@Component({
  selector: 'app-spreadsheet-header-cell',
  templateUrl: './header-cell.component.html',
  styleUrls: ['./header-cell.component.scss'],
})
export class HeaderCellComponent {
  @Input() width: number;
  @Input() height: number;
  @Input() cell: Cell;
  @Input() columns: Row;
  @Input() row: Row;
  private rowClickCount = 0;
  private colClickCount = 0;

  constructor(
    public selectionModel: SelectionModelService,
  ) { }

  mouse(event: MouseEvent, type: 'up' | 'down' | 'move') {
    // console.log(this.columns)
    switch (type) {
      /*case 'down':
        this.selectionModel.down(event, this.cell, this.columns);
        break;
      case 'up':
        this.selectionModel.up(event, this.cell, this.columns);
        break;
      case 'move':
        this.selectionModel.over(event, this.cell, this.columns);
        break;*/
    }

  }

  onDragEnd(event: CdkDragEnd, type: 'x' | 'y') {
    switch (type) {
      case 'x':
        this.cell.width += event.distance.x;
        break;
      case 'y':
        this.row.height += event.distance.y;
        break;
    }

    event.source.reset();
  }

  onColDragClick(event: MouseEvent) {
    if (this.colClickCount === 1) {
      this.cell.width = 100;
    } else {
      this.colClickCount++;
    }

    setTimeout(() => {
      this.colClickCount = 0;
    }, 400);
  }

  onRowDragClick(event: MouseEvent) {
    if (this.rowClickCount === 1) {
      this.row.height = 30;
    } else {
      this.rowClickCount++;
    }

    setTimeout(() => {
      this.rowClickCount = 0;
    }, 400);
  }
}
