import { ScrollingModule } from '@angular/cdk/scrolling';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SpreadsheetComponent } from './spreadsheet.component';


@NgModule({
  imports: [
    CommonModule,
    ScrollingModule,
  ],
  declarations: [
    SpreadsheetComponent
  ],
  exports: [SpreadsheetComponent]
})
export class SpreadsheetModule { }
