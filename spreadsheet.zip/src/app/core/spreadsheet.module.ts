import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CellModule } from './cell/cell.module';
import { HeaderCellModule } from './header-cell/header-cell.module';
import { SpreadsheetComponent } from './spreadsheet.component';
import { VirtualScrollModule } from './virtual-scroll/virtual-scroll.module';

@NgModule({
  imports: [
    CommonModule,
    VirtualScrollModule,
    CellModule,
    HeaderCellModule,
  ],
  declarations: [
    SpreadsheetComponent,
  ],
  exports: [SpreadsheetComponent]
})
export class SpreadsheetModule { }
