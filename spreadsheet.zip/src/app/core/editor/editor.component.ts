import { Component, Input, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { Cell } from '../cell';

@Component({
  selector: 'app-editor',
  templateUrl: './editor.component.html',
  styleUrls: ['./editor.component.scss'],
})
export class EditorComponent implements AfterViewInit {
  @Input() cell: Cell;
  @ViewChild('editor', { static: true }) editor: ElementRef;

  ngAfterViewInit(): void {
    this.editor.nativeElement.focus();
  }
}
