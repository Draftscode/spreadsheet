import { AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, HostListener, Input, OnInit, ViewChild } from '@angular/core';
import { Cell } from './cell';
import { SelectionModelService } from './provider/selection-model.service';
import { Row } from './row';

@Component({
  selector: 'app-spreadsheet',
  templateUrl: './spreadsheet.component.html',
  styleUrls: ['./spreadsheet.component.scss'],
  providers: [SelectionModelService],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SpreadsheetComponent implements OnInit, AfterViewInit {
  @Input() columns: Row;
  @Input() rows: Row[];
  /*@ViewChild('verticalHeader', { static: true }) verticalHeader: ElementRef;
  @ViewChild('horizontalHeader', { static: true }) horizontalHeader: ElementRef;*/
  @ViewChild('content', { static: false }) content: ElementRef;

  @HostListener('document:click', ['$event']) clickout(event) {
    if (!this.app.nativeElement.contains(event.target)) { this.selectionModel.clearSelection(); }
  }

  constructor(
    private cd: ChangeDetectorRef,
    private app: ElementRef,
    private selectionModel: SelectionModelService,
  ) { }

  get combinedRowHeight(): number {
    return this.rows.map((row: Row) => row.height).reduce((accu: number, cur: number) => accu + cur);
  }

  get combinedColWidth(): number {
    return this.columns.cells.map((col: Cell) => col.width).reduce((accu: number, cur: number) => accu + cur);
  }

  ngOnInit() {
    this.cd.detectChanges();
  }

  ngAfterViewInit() {
    this.cd.detectChanges();
  }

  get scrollbarWidth(): number {
    if (!this.content) { return 0; }
    return this.content.nativeElement.offsetWidth - this.content.nativeElement.clientWidth;
  }
}
