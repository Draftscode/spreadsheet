

export class Spreadsheet {
    constructor() { }
}
