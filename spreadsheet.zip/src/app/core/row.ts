import { Cell } from './cell';

export class Row {
  cells: Cell[];
  height: number;
  index: number;
  label: string;

}
