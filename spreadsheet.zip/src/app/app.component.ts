import { Component, ViewChild, OnInit } from '@angular/core';
import { Row } from './core/row';
import { Cell } from './core/cell';
import { SpreadsheetComponent } from './core/spreadsheet.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  @ViewChild(SpreadsheetComponent, { static: true }) spreadsheetInstance: SpreadsheetComponent;
  rows: Row[];
  columns: Row;
  rowCount = 100;
  colCount = 10;
  constructor() {
    // const columns = new Array(this.colCount);
    const rows = new Array(this.rowCount);
    const columns = new Row();
    columns.height = 25;
    columns.cells = new Array(this.colCount);
    for (let x = 0; x < this.colCount; x++) {
      const cell = new Cell(x, 0, `${x}: ${0}`);
      cell.width = 100;
      columns.cells[x] = cell;
    }

    for (let y = 0; y < this.rowCount; y++) {
      const row = new Row();
      row.index = y;
      row.label = `${y}`;
      row.height = 30;
      const cells = new Array(this.colCount);
      for (let x = 0; x < this.colCount; x++) {
        const cell = new Cell();
        cell.row = y; cell.col = x; cell.value = cell.label = `${cell.row}: ${cell.col}`;
        cells[x] = cell;
      }
      row.cells = cells;
      rows[y] = row;
    }

    this.columns = columns;
    this.rows = rows;
  }

  ngOnInit() {
  }

  private getRandomArbitrary(min: number, max: number) {
    return Math.floor(Math.random() * (max - min) + min);
  }
}
